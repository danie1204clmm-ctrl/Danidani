import React, { useState, useMemo } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, Image,
  StyleSheet, TextInput, Alert,
} from 'react-native';
import { useApp } from '../context/AppContext';
import { C, CAT_SIMPLES, CAT_MIN_QTY } from '../services/config';
import { fmt } from '../services/helpers';

const BREADS = ['Pão de Hambúrguer', 'Pão Francês'];
const REMOVALS = ['Alface','Tomate','Milho','Cebola','Picles','Molho','Maionese','Mostarda','Ketchup','Pepino'];

export default function ProductScreen({ route, navigation }) {
  const { item } = route.params;
  const { extras: EXTRAS, addToCart } = useApp();
  const [qty, setQty]         = useState(1);
  const [extQty, setExtQty]   = useState({});
  const [removals, setRemovals] = useState({});
  const [bread, setBread]     = useState('');
  const [obs, setObs]         = useState('');
  const isSimple = CAT_SIMPLES.includes(item.cat);
  const minQ     = CAT_MIN_QTY[item.cat] || 1;
  const basePrice = (item.promo && item.promoPrice) ? item.promoPrice : item.price;

  const extTotal = useMemo(
    () => isSimple ? 0 : EXTRAS.reduce((s, e) => s + (extQty[e.id || e._id] || 0) * e.price, 0),
    [extQty, EXTRAS, isSimple]
  );
  const total = (basePrice + extTotal) * qty;

  function toggleExt(id) {
    setExtQty(prev => ({ ...prev, [id]: prev[id] ? 0 : 1 }));
  }
  function toggleRem(name) {
    setRemovals(prev => ({ ...prev, [name]: !prev[name] }));
  }

  function handleAdd() {
    if (qty < minQ) { Alert.alert('Atenção', `Mínimo ${minQ} unidades para ${item.cat}!`); return; }
    const extArr = isSimple ? [] : EXTRAS.filter(e => (extQty[e.id || e._id] || 0) > 0).map(e => ({ ...e, qty: extQty[e.id || e._id] }));
    const remArr = isSimple ? [] : Object.keys(removals).filter(k => removals[k]);
    addToCart(item, qty, extArr, remArr, isSimple ? '' : bread, obs);
    navigation.goBack();
  }

  return (
    <View style={s.bg}>
      {/* Close */}
      <TouchableOpacity style={s.closeBtn} onPress={() => navigation.goBack()}>
        <Text style={s.closeX}>✕</Text>
      </TouchableOpacity>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Imagem ou emoji */}
        {item.photos?.length > 0
          ? <Image source={{ uri: item.photos[0] }} style={s.img} resizeMode="cover" />
          : <View style={s.emojiWrap}><Text style={{ fontSize: 80 }}>{item.emoji || '🍽️'}</Text></View>
        }

        <View style={s.body}>
          <Text style={s.name}>{item.name}</Text>
          {item.desc ? <Text style={s.desc}>{item.desc}</Text> : null}

          {item.promo && item.promoPrice ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 8 }}>
              <Text style={s.promoPrice}>R$ {fmt(item.promoPrice)}</Text>
              <Text style={s.oldPrice}>R$ {fmt(item.price)}</Text>
              <View style={s.discBadge}>
                <Text style={s.discTxt}>-{Math.round((1 - item.promoPrice / item.price) * 100)}%</Text>
              </View>
            </View>
          ) : (
            <Text style={s.price}>R$ {fmt(item.price)}</Text>
          )}

          {/* Pão */}
          {!isSimple && item.breads?.length > 0 && (
            <>
              <Text style={s.secTitle}>Escolha o pão</Text>
              <View style={s.breadRow}>
                {(item.breads || BREADS).map(b => (
                  <TouchableOpacity key={b} style={[s.breadBtn, bread === b && s.breadOn]} onPress={() => setBread(b)}>
                    <Text style={[s.breadTxt, bread === b && s.breadTxtOn]}>{b}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </>
          )}

          {/* Adicionais */}
          {!isSimple && EXTRAS.length > 0 && (
            <>
              <Text style={s.secTitle}>Adicionais <Text style={s.secSub}>(preço extra)</Text></Text>
              {EXTRAS.map(e => {
                const id = e.id || e._id;
                const on = (extQty[id] || 0) > 0;
                return (
                  <TouchableOpacity key={id} style={[s.extraRow, on && s.extraOn]} onPress={() => toggleExt(id)}>
                    <Text style={s.extraLabel}>{e.label}</Text>
                    <Text style={s.extraPrice}>+R$ {fmt(e.price)}</Text>
                  </TouchableOpacity>
                );
              })}
            </>
          )}

          {/* Remover ingredientes */}
          {!isSimple && (
            <>
              <Text style={s.secTitle}>Remover ingredientes</Text>
              <View style={s.chipsRow}>
                {REMOVALS.map(r => (
                  <TouchableOpacity key={r} style={[s.chip, removals[r] && s.chipOn]} onPress={() => toggleRem(r)}>
                    <Text style={[s.chipTxt, removals[r] && s.chipTxtOn]}>{removals[r] ? '✕ ' : ''}{r}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </>
          )}

          {/* Observações */}
          <Text style={s.secTitle}>Observações</Text>
          <TextInput
            style={s.obsInput} value={obs} onChangeText={setObs}
            placeholder="Ex: sem molho, bem passado..."
            placeholderTextColor={C.grayL}
            multiline numberOfLines={2}
          />
        </View>
      </ScrollView>

      {/* Footer */}
      <View style={s.footer}>
        <View style={s.qCtrl}>
          <TouchableOpacity style={s.qBtn} onPress={() => setQty(q => Math.max(minQ, q - 1))}>
            <Text style={s.qBtnTxt}>−</Text>
          </TouchableOpacity>
          <Text style={s.qNum}>{qty}</Text>
          <TouchableOpacity style={s.qBtn} onPress={() => setQty(q => q + 1)}>
            <Text style={s.qBtnTxt}>+</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={s.addBtn} onPress={handleAdd}>
          <Text style={s.addBtnTxt}>Adicionar  R$ {fmt(total)}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  bg:          { flex: 1, backgroundColor: '#fff' },
  closeBtn:    { position: 'absolute', top: 46, right: 14, zIndex: 10, backgroundColor: C.red, borderRadius: 20, width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  closeX:      { color: '#fff', fontSize: 16, fontWeight: '700' },
  img:         { width: '100%', height: 270 },
  emojiWrap:   { height: 200, backgroundColor: '#f5f5f5', justifyContent: 'center', alignItems: 'center' },
  body:        { padding: 18, paddingBottom: 6 },
  name:        { fontSize: 22, fontWeight: '900', color: '#111' },
  desc:        { fontSize: 14, color: '#666', marginTop: 6, lineHeight: 20 },
  price:       { fontSize: 24, fontWeight: '700', color: C.gold, marginTop: 8 },
  promoPrice:  { fontSize: 24, fontWeight: '700', color: C.gold },
  oldPrice:    { fontSize: 15, color: '#999', textDecorationLine: 'line-through' },
  discBadge:   { backgroundColor: C.red + '22', borderRadius: 8, paddingHorizontal: 7, paddingVertical: 2 },
  discTxt:     { color: C.red, fontSize: 12, fontWeight: '700' },
  secTitle:    { fontSize: 12, fontWeight: '700', color: '#777', textTransform: 'uppercase', letterSpacing: 1, marginTop: 20, marginBottom: 10 },
  secSub:      { fontSize: 10, color: '#bbb', textTransform: 'none', letterSpacing: 0 },
  breadRow:    { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  breadBtn:    { borderWidth: 2, borderColor: '#ddd', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 8 },
  breadOn:     { borderColor: C.gold, backgroundColor: C.gold + '11' },
  breadTxt:    { fontSize: 13, color: '#555', fontWeight: '600' },
  breadTxtOn:  { color: C.gold },
  extraRow:    { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 12, borderRadius: 10, borderWidth: 2, borderColor: '#eee', marginBottom: 8 },
  extraOn:     { borderColor: C.gold, backgroundColor: C.gold + '11' },
  extraLabel:  { fontSize: 14, color: '#333', fontWeight: '600' },
  extraPrice:  { fontSize: 14, color: C.gold, fontWeight: '700' },
  chipsRow:    { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip:        { borderWidth: 2, borderColor: '#ddd', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 6 },
  chipOn:      { borderColor: C.red, backgroundColor: C.red + '11' },
  chipTxt:     { fontSize: 12, color: '#555', fontWeight: '600' },
  chipTxtOn:   { color: C.red },
  obsInput:    { borderWidth: 2, borderColor: '#eee', borderRadius: 10, padding: 12, fontSize: 14, color: '#333', textAlignVertical: 'top', minHeight: 64 },
  footer:      { flexDirection: 'row', padding: 14, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#eee', gap: 10, alignItems: 'center' },
  qCtrl:       { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f5f5f5', borderRadius: 12, paddingHorizontal: 8 },
  qBtn:        { padding: 10 },
  qBtnTxt:     { fontSize: 22, fontWeight: '700', color: '#333' },
  qNum:        { fontSize: 18, fontWeight: '700', color: '#111', minWidth: 28, textAlign: 'center' },
  addBtn:      { flex: 1, backgroundColor: C.gold, borderRadius: 13, padding: 14, alignItems: 'center' },
  addBtnTxt:   { color: C.dark, fontWeight: '700', fontSize: 16 },
});
