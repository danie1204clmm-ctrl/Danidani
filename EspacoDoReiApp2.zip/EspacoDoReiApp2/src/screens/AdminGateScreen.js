import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { ADMIN_USER, ADMIN_PASS, C } from '../services/config';

export default function AdminGateScreen({ navigation }) {
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');

  function login() {
    if (user === ADMIN_USER && pass === ADMIN_PASS) {
      navigation.navigate('AdminPanel');
    } else {
      Alert.alert('Erro', 'Usuário ou senha incorretos.');
    }
  }

  return (
    <View style={s.bg}>
      <Text style={s.title}>⚙️ Área Admin</Text>
      <View style={s.card}>
        <Text style={s.lbl}>Usuário</Text>
        <TextInput style={s.inp} value={user} onChangeText={setUser} placeholder="admin" placeholderTextColor={C.grayL} autoCapitalize="none" />
        <Text style={s.lbl}>Senha</Text>
        <TextInput style={s.inp} value={pass} onChangeText={setPass} placeholder="••••••" placeholderTextColor={C.grayL} secureTextEntry onSubmitEditing={login} />
        <TouchableOpacity style={s.btn} onPress={login}>
          <Text style={s.btnTxt}>Entrar no Painel</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  bg:    { flex: 1, backgroundColor: C.dark, justifyContent: 'center', padding: 24 },
  title: { color: C.gold, fontSize: 24, fontWeight: '900', textAlign: 'center', marginBottom: 28 },
  card:  { backgroundColor: C.dark2, borderRadius: 20, padding: 20, borderWidth: 1, borderColor: C.border },
  lbl:   { color: C.grayL, fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6, marginTop: 12 },
  inp:   { backgroundColor: C.dark, borderWidth: 2, borderColor: '#2a2a2a', borderRadius: 12, padding: 13, color: C.white, fontSize: 15, marginBottom: 4 },
  btn:   { backgroundColor: C.gold, borderRadius: 13, padding: 14, alignItems: 'center', marginTop: 18 },
  btnTxt:{ color: C.dark, fontWeight: '700', fontSize: 16 },
});
