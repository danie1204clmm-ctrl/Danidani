# Espaço do Rei — App React Native (Expo)

## Pré-requisitos
- Node.js 18+
- VSCode
- **Expo Go** instalado no celular (Play Store / App Store)

## Instalação (passo a passo)

### 1. Abra a pasta no VSCode
```
Arquivo → Abrir Pasta → selecione a pasta EspacoDoReiApp
```

### 2. Abra o terminal no VSCode
```
Terminal → Novo Terminal
```

### 3. Instale as dependências
```bash
npm install
```

### 4. Inicie o projeto
```bash
npx expo start
```

### 5. Escaneie o QR Code
- Abra o **Expo Go** no celular
- Escaneie o QR Code que aparece no terminal
- O app abre automaticamente

---

## Estrutura do projeto

```
EspacoDoReiApp/
├── App.js                              ← Entrada do app
├── app.json                            ← Config Expo
├── package.json                        ← Dependências
├── babel.config.js
└── src/
    ├── context/
    │   └── AppContext.js               ← Estado global + Firebase listeners
    ├── navigation/
    │   └── AppNavigator.js             ← Rotas do app
    ├── services/
    │   ├── config.js                   ← Todas as constantes (WA, Firebase, cores...)
    │   ├── firebase.js                 ← Inicialização Firebase
    │   └── helpers.js                  ← Funções utilitárias
    └── screens/
        ├── LoginScreen.js              ← Login por telefone / cadastro
        ├── MenuScreen.js               ← Cardápio com categorias
        ├── ProductScreen.js            ← Detalhe do produto + adicionais
        ├── CartScreen.js               ← Carrinho + checkout + WhatsApp
        ├── ReginaScreen.js             ← Garçonete IA por voz
        ├── AccountScreen.js            ← Minha conta + endereços
        ├── AdminGateScreen.js          ← Login admin
        └── AdminPanelScreen.js         ← Painel admin (pedidos/cardápio/clientes)
```

---

## Telas do app

| Tela | Descrição |
|------|-----------|
| Login | Busca cliente por telefone ou cria conta nova |
| Cardápio | Grade de produtos por categoria, promoções em destaque |
| Produto | Foto, adicionais, remover ingredientes, quantidade |
| Carrinho | Lista de itens, checkout com endereço e pagamento |
| Regina IA | Garçonete por voz — segure para falar |
| Minha Conta | Endereços salvos, adicionar/remover/definir principal |
| Admin | Pedidos em tempo real, avançar status, cardápio, clientes |

---

## Configurações (src/services/config.js)

- **WA** — número WhatsApp: `5512996277038`
- **ADMIN_USER / ADMIN_PASS** — `admin` / `rei123`
- **Firebase** — projeto `espaco-do-rei-3d788`
- **GEMINI_KEY** — chave da IA da Regina

---

## Nota sobre a Regina (voz)

O `@react-native-voice/voice` usa o microfone **nativo** do dispositivo.
No **Expo Go** pode ter limitações em alguns celulares.
Para funcionar 100%, gere o build de desenvolvimento:

```bash
npx expo run:android
```
