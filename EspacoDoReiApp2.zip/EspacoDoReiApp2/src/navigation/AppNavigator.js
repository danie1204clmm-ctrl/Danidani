import React from 'react';
import { Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { C } from '../services/config';

import LoginScreen       from '../screens/LoginScreen';
import MenuScreen        from '../screens/MenuScreen';
import ProductScreen     from '../screens/ProductScreen';
import CartScreen        from '../screens/CartScreen';
import AdminGateScreen   from '../screens/AdminGateScreen';
import AdminPanelScreen  from '../screens/AdminPanelScreen';
import AccountScreen     from '../screens/AccountScreen';

const Stack = createNativeStackNavigator();
const Tab   = createBottomTabNavigator();

function TabIcon({ emoji, color }) {
  return <Text style={{ fontSize: 20, color }}>{emoji}</Text>;
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: C.dark,
          borderTopColor: C.gold + '44',
          borderTopWidth: 1,
        },
        tabBarActiveTintColor:   C.gold,
        tabBarInactiveTintColor: C.grayL,
        tabBarLabelStyle: { fontSize: 11, fontWeight: '700' },
      }}
    >
      <Tab.Screen name="Menu" component={MenuScreen}
        options={{ tabBarLabel: 'Cardápio', tabBarIcon: ({ color }) => <TabIcon emoji="🍽️" color={color} /> }} />
      <Tab.Screen name="Cart" component={CartScreen}
        options={{ tabBarLabel: 'Carrinho', tabBarIcon: ({ color }) => <TabIcon emoji="🛒" color={color} /> }} />
      <Tab.Screen name="Account" component={AccountScreen}
        options={{ tabBarLabel: 'Minha Conta', tabBarIcon: ({ color }) => <TabIcon emoji="👤" color={color} /> }} />
      <Tab.Screen name="AdminGate" component={AdminGateScreen}
        options={{ tabBarLabel: 'Admin', tabBarIcon: ({ color }) => <TabIcon emoji="⚙️" color={color} /> }} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login"      component={LoginScreen} />
        <Stack.Screen name="Main"       component={MainTabs} />
        <Stack.Screen name="Product"    component={ProductScreen}    options={{ presentation: 'modal' }} />
        <Stack.Screen name="AdminPanel" component={AdminPanelScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
