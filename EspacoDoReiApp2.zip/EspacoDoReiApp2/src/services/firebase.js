import { initializeApp } from 'firebase/app';
import {
  getFirestore, collection, doc,
  getDocs, addDoc, updateDoc, deleteDoc,
  onSnapshot, serverTimestamp, query, orderBy,
} from 'firebase/firestore';
import { firebaseConfig } from './config';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

export {
  collection, doc, getDocs, addDoc, updateDoc,
  deleteDoc, onSnapshot, serverTimestamp, query, orderBy,
};
