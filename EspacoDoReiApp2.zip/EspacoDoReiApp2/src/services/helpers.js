export function fmt(v) {
  return parseFloat(v || 0).toFixed(2).replace('.', ',');
}

export function slug(str) {
  return (str || '').toLowerCase().replace(/[^a-z0-9]+/g, '-');
}

export function initials(name) {
  return (name || '?')
    .split(' ')
    .map(w => w[0])
    .join('')
    .substring(0, 2)
    .toUpperCase();
}

export function phoneDigits(phone) {
  return (phone || '').replace(/\D/g, '');
}

export function isItemVisibleToday(item) {
  const s = item.schedule;
  if (!s || s.mode === 'none' || !s.mode) return true;
  const today = new Date();
  if (s.mode === 'weekdays') {
    return (s.weekdays || []).includes(today.getDay());
  }
  if (s.mode === 'dates') {
    const todayStr = today.toISOString().slice(0, 10);
    return (s.dates || []).includes(todayStr);
  }
  return true;
}
