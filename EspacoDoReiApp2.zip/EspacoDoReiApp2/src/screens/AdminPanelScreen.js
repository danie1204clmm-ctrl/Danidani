import React, { useState } from 'react';
import { View, Text, FlatList, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { db, doc, updateDoc } from '../services/firebase';
import { useApp } from '../context/AppContext';
import { C } from '../services/config';
import { fmt, initials } from '../services/helpers';

const STATUS       = ['novo', 'preparo', 'pronto', 'entregue'];
const STATUS_LABEL = { novo: 'Novo', preparo: 'Em Preparo', pronto: 'Pronto', entregue: 'Entregue' };
const STATUS_COLOR = { novo: C.gold, preparo: '#e67e22', pronto: C.green, entregue: C.gray };

export default function AdminPanelScreen({ navigation }) {
  const { orders, items, clients } = useApp();
  const [tab, setTab]     = useState('pedidos');
  const [filter, setFilter] = useState('all');

  const novos    = orders.filter(o => o.status === 'novo').length;
  const revenue  = orders.reduce((s, o) => s + (o.total || 0), 0);
  const filtered = filter === 'all' ? orders : orders.filter(o => o.status === filter);

  async function nextStatus(order) {
    const idx = STATUS.indexOf(order.status);
    if (idx >= STATUS.length - 1) return;
    await updateDoc(doc(db, 'orders', order._id), { status: STATUS[idx + 1] });
  }

  return (
    <View style={s.bg}>
      <View style={s.header}>
        <Text style={s.title}>Painel Admin</Text>
        <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
          <Text style={s.backTxt}>Sair</Text>
        </TouchableOpacity>
      </View>

      {/* Stats */}
      <View style={s.stats}>
        {[
          { label: 'Pedidos',  val: orders.length },
          { label: 'Novos',    val: novos,         color: C.red },
          { label: 'Itens',    val: items.length },
          { label: 'Clientes', val: clients.length },
          { label: 'Receita',  val: `R$${fmt(revenue)}`, small: true },
        ].map(st => (
          <View key={st.label} style={s.stat}>
            <Text style={[s.statVal, st.color && { color: st.color }, st.small && { fontSize: 14 }]}>{st.val}</Text>
            <Text style={s.statLbl}>{st.label}</Text>
          </View>
        ))}
      </View>

      {/* Tabs */}
      <View style={s.tabs}>
        {[
          { id: 'pedidos',  label: `Pedidos${novos > 0 ? ` (${novos})` : ''}` },
          { id: 'cardapio', label: 'Cardápio' },
          { id: 'clientes', label: 'Clientes' },
        ].map(t => (
          <TouchableOpacity key={t.id} style={[s.tab, tab === t.id && s.tabOn]} onPress={() => setTab(t.id)}>
            <Text style={[s.tabTxt, tab === t.id && s.tabTxtOn]}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* ── PEDIDOS ── */}
      {tab === 'pedidos' && (
        <View style={{ flex: 1 }}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.filterBar}>
            {['all', ...STATUS].map(f => (
              <TouchableOpacity key={f} style={[s.filterBtn, filter === f && s.filterOn]} onPress={() => setFilter(f)}>
                <Text style={[s.filterTxt, filter === f && s.filterTxtOn]}>
                  {f === 'all' ? 'Todos' : STATUS_LABEL[f]}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
          <FlatList
            data={filtered}
            keyExtractor={o => o._id}
            contentContainerStyle={{ padding: 12, gap: 10 }}
            renderItem={({ item: o }) => (
              <View style={s.orderCard}>
                <View style={s.orderHead}>
                  <Text style={s.orderName}>{o.name}</Text>
                  <View style={[s.badge, { backgroundColor: STATUS_COLOR[o.status] + '22', borderColor: STATUS_COLOR[o.status] + '77' }]}>
                    <Text style={[s.badgeTxt, { color: STATUS_COLOR[o.status] }]}>{STATUS_LABEL[o.status]}</Text>
                  </View>
                </View>
                {o.address && (
                  <Text style={s.orderAddr}>📍 {o.address.rua}, {o.address.num} — {o.address.cidade}</Text>
                )}
                <Text style={s.orderItems}>{(o.items || []).map(i => `${i.qty}x ${i.name}`).join(', ')}</Text>
                <View style={s.orderFoot}>
                  <Text style={s.orderTotal}>R$ {fmt(o.total)}</Text>
                  {o.viaIA && <Text style={s.iaBadge}>Regina IA</Text>}
                  {o.status !== 'entregue' && (
                    <TouchableOpacity style={s.nextBtn} onPress={() => nextStatus(o)}>
                      <Text style={s.nextBtnTxt}>Avançar →</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            )}
          />
        </View>
      )}

      {/* ── CARDÁPIO ── */}
      {tab === 'cardapio' && (
        <FlatList
          data={items}
          keyExtractor={i => i._id}
          contentContainerStyle={{ padding: 12, gap: 8 }}
          renderItem={({ item: i }) => (
            <View style={s.menuItem}>
              <Text style={{ fontSize: 26 }}>{i.emoji || '🍽️'}</Text>
              <View style={{ flex: 1 }}>
                <Text style={s.menuName}>{i.name}</Text>
                <Text style={s.menuCat}>{i.cat}{i.promo ? '  🔥 PROMOÇÃO' : ''}</Text>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 4 }}>
                <Text style={s.menuPrice}>R$ {fmt(i.promo && i.promoPrice ? i.promoPrice : i.price)}</Text>
                <View style={[s.dot, { backgroundColor: i.avail ? C.green : C.red }]} />
              </View>
            </View>
          )}
        />
      )}

      {/* ── CLIENTES ── */}
      {tab === 'clientes' && (
        <FlatList
          data={clients}
          keyExtractor={c => c._id}
          contentContainerStyle={{ padding: 12, gap: 8 }}
          renderItem={({ item: c }) => (
            <View style={s.clientCard}>
              <View style={s.clientAv}>
                <Text style={s.clientAvTxt}>{initials(c.name)}</Text>
              </View>
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={s.clientName}>{c.name}</Text>
                <Text style={s.clientSub}>{c.phone}{c.email ? `  ·  ${c.email}` : ''}</Text>
                <Text style={s.clientSub}>📍 {(c.addresses || []).length} endereço(s)</Text>
              </View>
              <Text style={s.clientOrders}>{c.totalOrders || 0} pedidos</Text>
            </View>
          )}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  bg:          { flex: 1, backgroundColor: C.dark },
  header:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 54, paddingHorizontal: 18, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: C.gold + '33' },
  title:       { color: C.gold, fontSize: 20, fontWeight: '900' },
  backBtn:     { borderWidth: 1, borderColor: C.red + '66', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  backTxt:     { color: C.red, fontWeight: '700', fontSize: 13 },
  stats:       { flexDirection: 'row', padding: 12, gap: 8 },
  stat:        { flex: 1, backgroundColor: C.dark2, borderRadius: 10, padding: 10, alignItems: 'center', borderWidth: 1, borderColor: '#2a2a2a' },
  statVal:     { color: C.gold, fontSize: 20, fontWeight: '900' },
  statLbl:     { color: C.grayL, fontSize: 10, marginTop: 2 },
  tabs:        { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#2a2a2a' },
  tab:         { flex: 1, paddingVertical: 12, alignItems: 'center', borderBottomWidth: 3, borderBottomColor: 'transparent' },
  tabOn:       { borderBottomColor: C.gold },
  tabTxt:      { color: C.grayL, fontWeight: '700', fontSize: 13 },
  tabTxtOn:    { color: C.gold },
  filterBar:   { paddingHorizontal: 12, paddingVertical: 8, maxHeight: 52 },
  filterBtn:   { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, borderWidth: 1, borderColor: '#444', marginRight: 8 },
  filterOn:    { backgroundColor: C.gold + '22', borderColor: C.gold },
  filterTxt:   { color: C.grayL, fontSize: 12, fontWeight: '700' },
  filterTxtOn: { color: C.gold },
  orderCard:   { backgroundColor: C.dark2, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: '#2a2a2a', gap: 6 },
  orderHead:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  orderName:   { color: C.white, fontWeight: '700', fontSize: 15 },
  badge:       { borderRadius: 10, paddingHorizontal: 8, paddingVertical: 3, borderWidth: 1 },
  badgeTxt:    { fontSize: 11, fontWeight: '700' },
  orderAddr:   { color: C.grayL, fontSize: 12 },
  orderItems:  { color: '#aaa', fontSize: 13 },
  orderFoot:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  orderTotal:  { color: C.gold, fontSize: 18, fontWeight: '900' },
  iaBadge:     { backgroundColor: C.gold + '22', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3, borderWidth: 1, borderColor: C.gold + '55' },
  nextBtn:     { borderWidth: 1, borderColor: C.gold + '66', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  nextBtnTxt:  { color: C.gold, fontWeight: '700', fontSize: 13 },
  menuItem:    { flexDirection: 'row', alignItems: 'center', backgroundColor: C.dark2, borderRadius: 12, padding: 12, gap: 12, borderWidth: 1, borderColor: '#2a2a2a' },
  menuName:    { color: C.white, fontWeight: '700', fontSize: 14 },
  menuCat:     { color: C.grayL, fontSize: 12, marginTop: 2 },
  menuPrice:   { color: C.gold, fontWeight: '700', fontSize: 14 },
  dot:         { width: 8, height: 8, borderRadius: 4 },
  clientCard:  { flexDirection: 'row', alignItems: 'center', backgroundColor: C.dark2, borderRadius: 12, padding: 12, gap: 12, borderWidth: 1, borderColor: '#2a2a2a' },
  clientAv:    { width: 42, height: 42, borderRadius: 21, backgroundColor: C.gold, justifyContent: 'center', alignItems: 'center' },
  clientAvTxt: { color: C.dark, fontWeight: '900', fontSize: 14 },
  clientName:  { color: C.white, fontWeight: '700', fontSize: 14 },
  clientSub:   { color: C.grayL, fontSize: 12 },
  clientOrders:{ color: C.gold, fontWeight: '700', fontSize: 13 },
});
