// ===== FIREBASE =====
export const firebaseConfig = {
  apiKey: 'AIzaSyCnDprCy8iLygZrW07ClJHilF-AkJRH-p4',
  authDomain: 'espaco-do-rei-3d788.firebaseapp.com',
  projectId: 'espaco-do-rei-3d788',
  storageBucket: 'espaco-do-rei-3d788.firebasestorage.app',
  messagingSenderId: '1082807253721',
  appId: '1:1082807253721:web:30b381cc3fb0f1a5fcdcc8',
};

// ===== APP =====
export const ADMIN_USER = 'admin';
export const ADMIN_PASS = 'rei123';
export const WA = '5512996277038';
export const PIX_KEY = '12996277038';
export const PIX_NOME = 'Espaco do Rei';

// ===== CATEGORIAS =====
export const CATI = {
  'Lanches Artesanais': '🍔',
  'Porções': '🍟',
  'Bebidas': '🥤',
  'Doces': '🍮',
  'Pizza': '🍕',
  'Pizza Doce': '🍰',
  'Lanche': '🥪',
  'Esfihas': '🫓',
};

export const CAT_SIMPLES = ['Bebidas', 'Doces'];
export const CAT_MIN_QTY = { Pizza: 1, 'Pizza Doce': 1, Lanche: 1, Esfihas: 5 };

// ===== ADICIONAIS =====
export const EXTRAS_DEFAULT = [
  { id: 'carne',    label: 'Carne extra',  price: 6.00 },
  { id: 'queijo',   label: 'Queijo extra', price: 3.00 },
  { id: 'bacon',    label: 'Bacon',        price: 4.00 },
  { id: 'ovo',      label: 'Ovo',          price: 2.50 },
  { id: 'cheddar',  label: 'Cheddar',      price: 3.50 },
  { id: 'catupiry', label: 'Catupiry',     price: 3.50 },
  { id: 'parmesao', label: 'Parmesão',     price: 3.00 },
];

export const REMOVALS_DEFAULT = [
  'Alface','Tomate','Milho','Cebola','Picles',
  'Molho','Maionese','Mostarda','Ketchup','Pepino',
];

// ===== PAGAMENTOS =====
export const PAY_LABELS = {
  pix:      'PIX',
  credito:  'Cartão de Crédito',
  debito:   'Cartão de Débito',
  dinheiro: 'Dinheiro',
};

// ===== CORES =====
export const C = {
  black:   '#0a0a0a',
  dark:    '#111111',
  dark2:   '#1a1a1a',
  gold:    '#D4A017',
  goldL:   '#F0B429',
  goldP:   '#FFD700',
  silver:  '#C0C0C0',
  silverL: '#E8E8E8',
  white:   '#F0F0F0',
  red:     '#C0392B',
  green:   '#27AE60',
  gray:    '#555555',
  grayL:   '#888888',
  border:  'rgba(212,160,23,0.25)',
};
