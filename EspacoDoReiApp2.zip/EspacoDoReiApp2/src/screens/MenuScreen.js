import React, { useState, useMemo } from 'react';
import {
  View, Text, ScrollView, FlatList, TouchableOpacity,
  Image, StyleSheet, TextInput,
} from 'react-native';
import { useApp } from '../context/AppContext';
import { C, CATI } from '../services/config';
import { fmt, isItemVisibleToday } from '../services/helpers';

export default function MenuScreen({ navigation }) {
  const { items, cartCount } = useApp();
  const [selCat, setSelCat] = useState('all');

  const av = useMemo(
    () => items.filter(i => i.avail && isItemVisibleToday(i)),
    [items]
  );
  const promos = useMemo(() => av.filter(i => i.promo), [av]);
  const cats   = useMemo(() => [...new Set(av.map(i => i.cat))].filter(c => av.some(i => i.cat === c && !i.promo)), [av]);

  const displayed = useMemo(() => {
    if (selCat === 'all')   return av;
    if (selCat === 'promo') return promos;
    return av.filter(i => i.cat === selCat && !i.promo);
  }, [selCat, av, promos]);

  return (
    <View style={s.bg}>
      {/* Header */}
      <View style={s.header}>
        <Text style={s.logo}>👑 Espaço do Rei</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Cart')} style={s.cartWrap}>
          <Text style={s.cartIco}>🛒</Text>
          {cartCount > 0 && (
            <View style={s.badge}><Text style={s.badgeTxt}>{cartCount}</Text></View>
          )}
        </TouchableOpacity>
      </View>

      {/* Cat bar */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.catBar}>
        {[
          { id: 'all', label: '⭐ Todos' },
          ...(promos.length ? [{ id: 'promo', label: '🔥 Promoções' }] : []),
          ...cats.map(c => ({ id: c, label: `${CATI[c] || '🍽️'} ${c}` })),
        ].map(tab => (
          <TouchableOpacity
            key={tab.id}
            style={[s.catTab, selCat === tab.id && s.catOn]}
            onPress={() => setSelCat(tab.id)}
          >
            <Text style={[s.catTxt, selCat === tab.id && s.catTxtOn]}>{tab.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Grid */}
      <FlatList
        data={displayed}
        keyExtractor={i => i._id}
        numColumns={2}
        contentContainerStyle={s.grid}
        ListEmptyComponent={
          <View style={s.empty}>
            <Text style={{ fontSize: 40, marginBottom: 8 }}>🍽️</Text>
            <Text style={s.emptyTxt}>Cardápio sendo preparado...</Text>
          </View>
        }
        renderItem={({ item }) => (
          <ProductCard item={item} onPress={() => navigation.navigate('Product', { item })} />
        )}
      />
    </View>
  );
}

function ProductCard({ item, onPress }) {
  const price = item.promo && item.promoPrice ? item.promoPrice : item.price;
  return (
    <TouchableOpacity style={s.card} onPress={onPress} activeOpacity={0.85}>
      {item.promo && (
        <View style={s.promoBadge}><Text style={s.promoBadgeTxt}>🔥 PROMOÇÃO</Text></View>
      )}
      {item.photos?.length > 0
        ? <Image source={{ uri: item.photos[0] }} style={s.cardImg} resizeMode="cover" />
        : <View style={s.emojiWrap}><Text style={{ fontSize: 44 }}>{item.emoji || '🍽️'}</Text></View>
      }
      <View style={s.cardBody}>
        <Text style={s.cardName} numberOfLines={2}>{item.name}</Text>
        {item.promo && item.promoPrice ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 6 }}>
            <Text style={s.promoPrice}>R$ {fmt(item.promoPrice)}</Text>
            <Text style={s.oldPrice}>R$ {fmt(item.price)}</Text>
          </View>
        ) : (
          <Text style={s.price}>R$ {fmt(price)}</Text>
        )}
      </View>
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  bg:           { flex: 1, backgroundColor: '#f5f5f5' },
  header:       { backgroundColor: C.dark, paddingTop: 52, paddingHorizontal: 16, paddingBottom: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  logo:         { color: C.gold, fontSize: 18, fontWeight: '900' },
  cartWrap:     { position: 'relative', padding: 4 },
  cartIco:      { fontSize: 24 },
  badge:        { position: 'absolute', top: 0, right: 0, backgroundColor: C.red, borderRadius: 9, minWidth: 18, height: 18, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 3 },
  badgeTxt:     { color: '#fff', fontSize: 10, fontWeight: '700' },
  catBar:       { backgroundColor: '#fff', maxHeight: 52, borderBottomWidth: 2, borderBottomColor: C.gold + '33' },
  catTab:       { paddingHorizontal: 14, paddingVertical: 14, borderBottomWidth: 3, borderBottomColor: 'transparent' },
  catOn:        { borderBottomColor: C.gold },
  catTxt:       { fontSize: 13, fontWeight: '700', color: '#666' },
  catTxtOn:     { color: C.gold },
  grid:         { padding: 10, gap: 10 },
  card:         { flex: 1, backgroundColor: '#fff', borderRadius: 14, overflow: 'hidden', margin: 4, elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 5, borderWidth: 1, borderColor: '#eee' },
  promoBadge:   { position: 'absolute', top: 8, right: 8, backgroundColor: C.red, borderRadius: 10, paddingHorizontal: 7, paddingVertical: 3, zIndex: 2 },
  promoBadgeTxt:{ color: '#fff', fontSize: 9, fontWeight: '700' },
  cardImg:      { width: '100%', height: 130 },
  emojiWrap:    { width: '100%', height: 100, backgroundColor: '#f9f9f9', justifyContent: 'center', alignItems: 'center' },
  cardBody:     { padding: 10, gap: 4 },
  cardName:     { fontSize: 13, fontWeight: '700', color: '#111' },
  price:        { fontSize: 16, fontWeight: '700', color: C.gold },
  promoPrice:   { fontSize: 16, fontWeight: '700', color: C.gold },
  oldPrice:     { fontSize: 12, color: '#999', textDecorationLine: 'line-through' },
  empty:        { alignItems: 'center', paddingTop: 60 },
  emptyTxt:     { color: '#999', fontSize: 14 },
});
