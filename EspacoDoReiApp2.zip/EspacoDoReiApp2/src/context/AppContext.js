import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { db, collection, query, orderBy, onSnapshot } from '../services/firebase';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [items, setItems]     = useState([]);
  const [orders, setOrders]   = useState([]);
  const [clients, setClients] = useState([]);
  const [extras, setExtras]   = useState([]);
  const [ingredients, setIngredients] = useState([]);
  const [currentClient, setCurrentClient] = useState(null);
  const [cart, setCart]       = useState([]);
  const cartIdRef             = useRef(1);

  useEffect(() => {
    const subs = [];

    subs.push(onSnapshot(query(collection(db, 'items'), orderBy('createdAt', 'asc')), snap => {
      setItems(snap.docs.map(d => ({ ...d.data(), _id: d.id })));
    }));

    subs.push(onSnapshot(query(collection(db, 'orders'), orderBy('time', 'desc')), snap => {
      setOrders(snap.docs.map(d => ({ ...d.data(), _id: d.id })));
    }));

    subs.push(onSnapshot(query(collection(db, 'clients'), orderBy('createdAt', 'desc')), snap => {
      setClients(snap.docs.map(d => ({ ...d.data(), _id: d.id })));
    }));

    subs.push(onSnapshot(query(collection(db, 'extras'), orderBy('createdAt', 'asc')), snap => {
      if (!snap.empty) setExtras(snap.docs.map(d => ({ ...d.data(), _id: d.id })));
    }));

    subs.push(onSnapshot(query(collection(db, 'ingredients'), orderBy('createdAt', 'asc')), snap => {
      if (!snap.empty) setIngredients(snap.docs.map(d => ({ ...d.data(), _id: d.id })));
    }));

    return () => subs.forEach(u => u());
  }, []);

  // Atualizar dados do cliente logado em tempo real
  useEffect(() => {
    if (!currentClient?._id) return;
    const fresh = clients.find(c => c._id === currentClient._id);
    if (fresh) setCurrentClient(fresh);
  }, [clients]);

  // ── Cart ────────────────────────────────────────
  function addToCart(item, qty, extras = [], removals = [], bread = '', obs = '') {
    const basePrice = (item.promo && item.promoPrice) ? item.promoPrice : item.price;
    const up = basePrice + extras.reduce((s, e) => s + (e.qty || 1) * e.price, 0);
    const cid = cartIdRef.current++;
    setCart(prev => [...prev, { cid, item, qty, extras, removals, bread, obs, up }]);
  }

  function removeFromCart(cid) {
    setCart(prev => prev.filter(c => c.cid !== cid));
  }

  function updateQty(cid, qty) {
    if (qty <= 0) { removeFromCart(cid); return; }
    setCart(prev => prev.map(c => c.cid === cid ? { ...c, qty } : c));
  }

  function clearCart() { setCart([]); }

  const cartTotal = cart.reduce((s, c) => s + c.up * c.qty, 0);
  const cartCount = cart.reduce((s, c) => s + c.qty, 0);

  return (
    <AppContext.Provider value={{
      items, orders, clients, extras, ingredients,
      currentClient, setCurrentClient,
      cart, cartTotal, cartCount,
      addToCart, removeFromCart, updateQty, clearCart,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
