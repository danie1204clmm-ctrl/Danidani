import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, ActivityIndicator, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { db, collection, addDoc, serverTimestamp } from '../services/firebase';
import { useApp } from '../context/AppContext';
import { C } from '../services/config';
import { initials, phoneDigits } from '../services/helpers';

export default function LoginScreen({ navigation }) {
  const { clients, setCurrentClient } = useApp();
  const [phone, setPhone]             = useState('');
  const [name, setName]               = useState('');
  const [email, setEmail]             = useState('');
  const [found, setFound]             = useState(null);
  const [showReg, setShowReg]         = useState(false);
  const [loading, setLoading]         = useState(false);

  function onPhoneChange(val) {
    setPhone(val);
    setFound(null);
    setShowReg(false);
    const digits = phoneDigits(val);
    if (digits.length >= 10) {
      const match = clients.find(c => phoneDigits(c.phone) === digits);
      if (match) setFound(match);
      else setShowReg(true);
    }
  }

  function handleLogin() {
    setCurrentClient(found);
    navigation.replace('Main');
  }

  async function handleRegister() {
    if (!name.trim()) { Alert.alert('Atenção', 'Digite seu nome!'); return; }
    setLoading(true);
    try {
      const data = {
        name: name.trim(), phone: phone.trim(),
        email: email.trim(), addresses: [],
        createdAt: serverTimestamp(), lastOrder: null, totalOrders: 0,
      };
      const ref = await addDoc(collection(db, 'clients'), data);
      setCurrentClient({ ...data, _id: ref.id, addresses: [] });
      navigation.replace('Main');
    } catch {
      Alert.alert('Erro', 'Não foi possível criar a conta. Tente novamente.');
    }
    setLoading(false);
  }

  function skip() {
    setCurrentClient(null);
    navigation.replace('Main');
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView style={s.bg} contentContainerStyle={s.center} keyboardShouldPersistTaps="handled">
        <Text style={s.crown}>👑</Text>
        <Text style={s.title}>Espaço do Rei</Text>
        <Text style={s.sub}>FEITO COM AMOR, SABOR DE VERDADE</Text>

        <View style={s.card}>
          <Text style={s.lbl}>Seu telefone</Text>
          <TextInput
            style={s.input} value={phone} onChangeText={onPhoneChange}
            placeholder="(12) 99999-9999" placeholderTextColor={C.grayL}
            keyboardType="phone-pad" maxLength={16}
          />

          {/* Cliente encontrado */}
          {found && (
            <View style={s.foundBox}>
              <View style={s.avatar}><Text style={s.avatarTxt}>{initials(found.name)}</Text></View>
              <View style={{ flex: 1 }}>
                <Text style={s.foundName}>{found.name}</Text>
                <Text style={s.foundPhone}>{found.phone}</Text>
              </View>
            </View>
          )}
          {found && (
            <TouchableOpacity style={s.btn} onPress={handleLogin}>
              <Text style={s.btnTxt}>Entrar →</Text>
            </TouchableOpacity>
          )}

          {/* Cadastro */}
          {showReg && !found && (
            <>
              <Text style={s.divider}>Número não encontrado — cadastre-se</Text>
              <TextInput
                style={s.input} value={name} onChangeText={setName}
                placeholder="Seu nome completo *" placeholderTextColor={C.grayL}
              />
              <TextInput
                style={s.input} value={email} onChangeText={setEmail}
                placeholder="E-mail (opcional)" placeholderTextColor={C.grayL}
                keyboardType="email-address" autoCapitalize="none"
              />
              <TouchableOpacity style={s.btn} onPress={handleRegister} disabled={loading}>
                {loading
                  ? <ActivityIndicator color={C.dark} />
                  : <Text style={s.btnTxt}>Criar conta e entrar →</Text>
                }
              </TouchableOpacity>
            </>
          )}

          <TouchableOpacity style={s.skipBtn} onPress={skip}>
            <Text style={s.skipTxt}>Continuar sem entrar</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  bg:        { flex: 1, backgroundColor: C.black },
  center:    { flexGrow: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  crown:     { fontSize: 52, marginBottom: 8 },
  title:     { fontSize: 30, fontWeight: '900', color: C.gold, marginBottom: 4 },
  sub:       { fontSize: 11, color: C.grayL, letterSpacing: 2, marginBottom: 30, textAlign: 'center' },
  card:      { backgroundColor: C.dark2, borderRadius: 20, padding: 20, width: '100%', borderWidth: 1, borderColor: C.border },
  lbl:       { fontSize: 11, fontWeight: '700', color: C.grayL, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 },
  input:     { backgroundColor: C.dark, borderWidth: 2, borderColor: '#2a2a2a', borderRadius: 12, padding: 13, color: C.white, fontSize: 15, marginBottom: 10 },
  foundBox:  { flexDirection: 'row', alignItems: 'center', backgroundColor: C.dark, borderWidth: 2, borderColor: C.gold + '44', borderRadius: 12, padding: 12, marginBottom: 12, gap: 12 },
  avatar:    { width: 44, height: 44, borderRadius: 22, backgroundColor: C.gold, justifyContent: 'center', alignItems: 'center' },
  avatarTxt: { color: C.dark, fontWeight: '900', fontSize: 16 },
  foundName: { color: C.white, fontWeight: '700', fontSize: 15 },
  foundPhone:{ color: C.grayL, fontSize: 12, marginTop: 2 },
  btn:       { backgroundColor: C.gold, borderRadius: 13, padding: 14, alignItems: 'center', marginTop: 4 },
  btnTxt:    { color: C.dark, fontWeight: '700', fontSize: 16 },
  divider:   { color: C.grayL, fontSize: 12, textAlign: 'center', marginVertical: 12 },
  skipBtn:   { alignItems: 'center', marginTop: 18 },
  skipTxt:   { color: C.grayL, fontSize: 13, textDecorationLine: 'underline' },
});
