import React, { useState } from 'react';
import {
  View, Text, ScrollView, FlatList, TouchableOpacity,
  StyleSheet, Modal, Linking, Alert, ActivityIndicator,
} from 'react-native';
import { db, collection, addDoc, doc, updateDoc, serverTimestamp } from '../services/firebase';
import { useApp } from '../context/AppContext';
import { C, WA, PAY_LABELS } from '../services/config';
import { fmt } from '../services/helpers';

export default function CartScreen({ navigation }) {
  const { cart, cartTotal, cartCount, updateQty, clearCart, currentClient } = useApp();
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [selAddr, setSelAddr]           = useState(null);
  const [selPayment, setSelPayment]     = useState('pix');
  const [sending, setSending]           = useState(false);

  function openCheckout() {
    if (!currentClient) {
      Alert.alert('Faça login', 'Para finalizar um pedido é necessário estar logado.', [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Entrar', onPress: () => navigation.navigate('Login') },
      ]);
      return;
    }
    const addrs = currentClient.addresses || [];
    setSelAddr(addrs.find(a => a.default) || addrs[0] || null);
    setSelPayment('pix');
    setCheckoutOpen(true);
  }

  async function finalize() {
    setSending(true);
    try {
      const name = currentClient?.name || 'Cliente';
      const orderData = {
        name,
        clientId:    currentClient?._id || null,
        clientPhone: currentClient?.phone || '',
        address:     selAddr || null,
        pay:         selPayment,
        troco:       '',
        items: cart.map(c => ({
          name:     c.item.name,
          qty:      c.qty,
          up:       c.up,
          bread:    c.bread || '',
          extras:   c.extras,
          removals: c.removals,
          obs:      c.obs,
          emoji:    c.item.emoji || '',
          photo:    c.item.photos?.[0] || '',
        })),
        total:  cartTotal,
        status: 'novo',
        time:   Date.now(),
      };
      await addDoc(collection(db, 'orders'), orderData);
      if (currentClient?._id) {
        await updateDoc(doc(db, 'clients', currentClient._id), {
          lastOrder:   Date.now(),
          totalOrders: (currentClient.totalOrders || 0) + 1,
        });
      }
      const msg = buildMsg(name, orderData);
      await Linking.openURL(`https://wa.me/${WA}?text=${encodeURIComponent(msg)}`);
      clearCart();
      setCheckoutOpen(false);
    } catch (e) {
      console.error(e);
      Alert.alert('Erro', 'Não foi possível enviar o pedido. Tente novamente.');
    }
    setSending(false);
  }

  function buildMsg(name, o) {
    let msg = `👑 *NOVO PEDIDO — Espaço do Rei*\n\n`;
    msg += `👤 *Cliente:* ${name}`;
    if (o.clientPhone) msg += `\n📱 *Tel:* ${o.clientPhone}`;
    if (o.address) {
      const a = o.address;
      msg += `\n📍 *Endereço:* ${a.rua}, ${a.num}${a.comp ? ' - ' + a.comp : ''}${a.bairro ? ', ' + a.bairro : ''} — ${a.cidade}${a.cep ? ' (CEP ' + a.cep + ')' : ''}`;
    }
    msg += `\n💳 *Pagamento:* ${PAY_LABELS[o.pay] || o.pay}`;
    msg += `\n\n*Itens:*\n`;
    o.items.forEach((i, idx) => {
      msg += `\n${idx + 1}. *${i.qty}x ${i.name}* — R$ ${fmt(i.up * i.qty)}\n`;
      if (i.bread) msg += `   ${i.bread}\n`;
      i.extras?.forEach(e => msg += `   + ${e.label} (+R$ ${fmt(e.price * (e.qty || 1))})\n`);
      if (i.removals?.length) msg += `   Sem: ${i.removals.join(', ')}\n`;
      if (i.obs) msg += `   ${i.obs}\n`;
    });
    msg += `\n💰 *TOTAL: R$ ${fmt(o.total)}*\n\n_Espaço do Rei — App_`;
    return msg;
  }

  if (!cart.length) {
    return (
      <View style={[s.bg, { justifyContent: 'center', alignItems: 'center', gap: 12 }]}>
        <Text style={{ fontSize: 52 }}>🛒</Text>
        <Text style={s.emptyTxt}>Carrinho vazio</Text>
        <TouchableOpacity style={s.btn} onPress={() => navigation.navigate('Menu')}>
          <Text style={s.btnTxt}>Ver cardápio</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={s.bg}>
      <View style={s.header}><Text style={s.headerTxt}>Carrinho</Text></View>

      <FlatList
        data={cart}
        keyExtractor={c => String(c.cid)}
        contentContainerStyle={{ paddingBottom: 100 }}
        renderItem={({ item: c }) => (
          <View style={s.item}>
            <View style={s.itemEmoji}>
              <Text style={{ fontSize: 28 }}>{c.item.emoji || '🍽️'}</Text>
            </View>
            <View style={{ flex: 1, gap: 2 }}>
              <Text style={s.itemName}>{c.item.name}</Text>
              {c.extras?.length > 0 && (
                <Text style={s.itemMods}>{c.extras.map(e => e.label).join(', ')}</Text>
              )}
              {c.removals?.length > 0 && (
                <Text style={s.itemMods}>Sem: {c.removals.join(', ')}</Text>
              )}
              <Text style={s.itemPrice}>R$ {fmt(c.up * c.qty)}</Text>
            </View>
            <View style={s.qRow}>
              <TouchableOpacity style={s.qb} onPress={() => updateQty(c.cid, c.qty - 1)}>
                <Text style={s.qbTxt}>−</Text>
              </TouchableOpacity>
              <Text style={s.qn}>{c.qty}</Text>
              <TouchableOpacity style={s.qb} onPress={() => updateQty(c.cid, c.qty + 1)}>
                <Text style={s.qbTxt}>+</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
        ListFooterComponent={
          <View style={s.totalRow}>
            <Text style={s.totalLbl}>Total</Text>
            <Text style={s.totalVal}>R$ {fmt(cartTotal)}</Text>
          </View>
        }
      />

      <View style={s.footer}>
        <TouchableOpacity style={s.checkoutBtn} onPress={openCheckout}>
          <Text style={s.checkoutTxt}>Finalizar Pedido →</Text>
        </TouchableOpacity>
      </View>

      {/* ── Checkout Modal ── */}
      <Modal visible={checkoutOpen} animationType="slide" presentationStyle="pageSheet">
        <View style={s.modal}>
          <View style={s.modalHead}>
            <Text style={s.modalTitle}>Finalizar Pedido</Text>
            <TouchableOpacity style={s.modalX} onPress={() => setCheckoutOpen(false)}>
              <Text style={s.modalXTxt}>✕</Text>
            </TouchableOpacity>
          </View>

          <ScrollView contentContainerStyle={{ padding: 18, gap: 6 }}>
            {/* Endereços */}
            {(currentClient?.addresses?.length > 0) && (
              <>
                <Text style={s.secTtl}>Endereço de entrega</Text>
                {currentClient.addresses.map((a, i) => (
                  <TouchableOpacity
                    key={i}
                    style={[s.addrCard, selAddr === a && s.addrSel]}
                    onPress={() => setSelAddr(a)}
                  >
                    <Text style={s.addrType}>
                      {a.type === 'Casa' ? '🏠' : a.type === 'Trabalho' ? '🏢' : '📍'} {a.type}
                      {selAddr === a ? '  ✓' : ''}
                    </Text>
                    <Text style={s.addrTxt}>{a.rua}, {a.num}{a.comp ? ` — ${a.comp}` : ''} — {a.cidade}</Text>
                  </TouchableOpacity>
                ))}
              </>
            )}

            {/* Resumo */}
            <Text style={s.secTtl}>Resumo do pedido</Text>
            {cart.map(c => (
              <View key={c.cid} style={s.sumRow}>
                <Text style={s.sumItem}>{c.qty}x {c.item.name}</Text>
                <Text style={s.sumPrice}>R$ {fmt(c.up * c.qty)}</Text>
              </View>
            ))}
            <View style={[s.sumRow, s.sumTotal]}>
              <Text style={{ color: C.gold, fontWeight: '700' }}>Total</Text>
              <Text style={{ color: C.gold, fontWeight: '700' }}>R$ {fmt(cartTotal)}</Text>
            </View>

            {/* Pagamento */}
            <Text style={s.secTtl}>Forma de pagamento</Text>
            {Object.entries(PAY_LABELS).map(([key, label]) => (
              <TouchableOpacity
                key={key}
                style={[s.payOpt, selPayment === key && s.payOn]}
                onPress={() => setSelPayment(key)}
              >
                <Text style={s.payLbl}>{label}</Text>
                {selPayment === key && <Text style={{ color: C.gold, fontSize: 18 }}>✓</Text>}
              </TouchableOpacity>
            ))}
          </ScrollView>

          <View style={s.footer}>
            <TouchableOpacity style={[s.checkoutBtn, sending && { opacity: 0.6 }]} onPress={finalize} disabled={sending}>
              {sending
                ? <ActivityIndicator color={C.dark} />
                : <Text style={s.checkoutTxt}>Confirmar no WhatsApp 📲</Text>
              }
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  bg:          { flex: 1, backgroundColor: C.dark },
  header:      { backgroundColor: C.dark, paddingTop: 54, paddingHorizontal: 18, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: C.gold + '33' },
  headerTxt:   { color: C.gold, fontSize: 20, fontWeight: '900' },
  emptyTxt:    { color: C.grayL, fontSize: 16 },
  btn:         { backgroundColor: C.gold, borderRadius: 12, paddingHorizontal: 24, paddingVertical: 12 },
  btnTxt:      { color: C.dark, fontWeight: '700', fontSize: 15 },
  item:        { flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderBottomColor: '#222', gap: 12 },
  itemEmoji:   { width: 52, height: 52, backgroundColor: C.dark2, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  itemName:    { color: C.white, fontWeight: '700', fontSize: 14 },
  itemMods:    { color: C.grayL, fontSize: 12 },
  itemPrice:   { color: C.gold, fontWeight: '700', fontSize: 14 },
  qRow:        { flexDirection: 'row', alignItems: 'center', gap: 8 },
  qb:          { width: 32, height: 32, borderRadius: 16, backgroundColor: '#333', justifyContent: 'center', alignItems: 'center' },
  qbTxt:       { color: C.white, fontSize: 20, fontWeight: '700' },
  qn:          { color: C.white, fontSize: 16, fontWeight: '700', minWidth: 24, textAlign: 'center' },
  totalRow:    { flexDirection: 'row', justifyContent: 'space-between', padding: 18, borderTopWidth: 2, borderTopColor: C.gold + '44' },
  totalLbl:    { color: C.white, fontSize: 16, fontWeight: '700' },
  totalVal:    { color: C.gold, fontSize: 22, fontWeight: '900' },
  footer:      { padding: 14, backgroundColor: C.dark, borderTopWidth: 1, borderTopColor: '#222' },
  checkoutBtn: { backgroundColor: C.gold, borderRadius: 13, padding: 15, alignItems: 'center' },
  checkoutTxt: { color: C.dark, fontWeight: '700', fontSize: 16 },
  modal:       { flex: 1, backgroundColor: C.dark },
  modalHead:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 54, paddingHorizontal: 18, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: C.gold + '33' },
  modalTitle:  { color: C.gold, fontSize: 18, fontWeight: '900' },
  modalX:      { backgroundColor: C.red, width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  modalXTxt:   { color: '#fff', fontWeight: '700', fontSize: 16 },
  secTtl:      { color: C.grayL, fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 1, marginTop: 16, marginBottom: 8 },
  addrCard:    { backgroundColor: C.dark2, borderWidth: 2, borderColor: '#333', borderRadius: 12, padding: 12, marginBottom: 8 },
  addrSel:     { borderColor: C.gold },
  addrType:    { color: C.white, fontWeight: '700', fontSize: 14 },
  addrTxt:     { color: C.grayL, fontSize: 12, marginTop: 3 },
  sumRow:      { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 },
  sumTotal:    { borderTopWidth: 2, borderTopColor: C.gold + '44', paddingTop: 8, marginTop: 4 },
  sumItem:     { color: C.white, fontSize: 14 },
  sumPrice:    { color: C.white, fontSize: 14, fontWeight: '700' },
  payOpt:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 14, backgroundColor: C.dark2, borderWidth: 2, borderColor: '#333', borderRadius: 12, marginBottom: 8 },
  payOn:       { borderColor: C.gold, backgroundColor: C.gold + '11' },
  payLbl:      { color: C.white, fontWeight: '700', fontSize: 15 },
});
