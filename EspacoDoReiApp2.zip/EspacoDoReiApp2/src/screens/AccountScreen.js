import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, Modal, Alert,
} from 'react-native';
import { db, doc, updateDoc } from '../services/firebase';
import { useApp } from '../context/AppContext';
import { C } from '../services/config';
import { initials } from '../services/helpers';

export default function AccountScreen({ navigation }) {
  const { currentClient, setCurrentClient } = useApp();
  const [addrModal, setAddrModal] = useState(false);
  const [addrType, setAddrType]   = useState('Casa');
  const [rua, setRua]   = useState('');
  const [num, setNum]   = useState('');
  const [bairro, setBairro] = useState('');
  const [comp, setComp] = useState('');
  const [cidade, setCidade] = useState('');
  const [cep, setCep]   = useState('');
  const [saving, setSaving] = useState(false);

  if (!currentClient) {
    return (
      <View style={[s.bg, { justifyContent: 'center', alignItems: 'center', gap: 14 }]}>
        <Text style={{ fontSize: 48 }}>👤</Text>
        <Text style={s.noLoginTxt}>Você não está logado</Text>
        <TouchableOpacity style={s.btn} onPress={() => navigation.navigate('Login')}>
          <Text style={s.btnTxt}>Entrar ou criar conta</Text>
        </TouchableOpacity>
      </View>
    );
  }

  async function saveAddr() {
    if (!rua.trim() || !num.trim() || !cidade.trim()) {
      Alert.alert('Atenção', 'Preencha rua, número e cidade!'); return;
    }
    setSaving(true);
    const addrs = [...(currentClient.addresses || [])];
    const isFirst = addrs.length === 0;
    addrs.push({ type: addrType, rua: rua.trim(), num: num.trim(), bairro: bairro.trim(), comp: comp.trim(), cidade: cidade.trim(), cep: cep.trim(), default: isFirst });
    try {
      await updateDoc(doc(db, 'clients', currentClient._id), { addresses: addrs });
      setCurrentClient(prev => ({ ...prev, addresses: addrs }));
      setAddrModal(false);
      setRua(''); setNum(''); setBairro(''); setComp(''); setCidade(''); setCep('');
    } catch { Alert.alert('Erro', 'Não foi possível salvar o endereço.'); }
    setSaving(false);
  }

  async function setDefault(idx) {
    const addrs = currentClient.addresses.map((a, i) => ({ ...a, default: i === idx }));
    await updateDoc(doc(db, 'clients', currentClient._id), { addresses: addrs });
    setCurrentClient(prev => ({ ...prev, addresses: addrs }));
  }

  async function removeAddr(idx) {
    const addrs = [...currentClient.addresses];
    const wasDefault = addrs[idx]?.default;
    addrs.splice(idx, 1);
    if (wasDefault && addrs.length) addrs[0].default = true;
    await updateDoc(doc(db, 'clients', currentClient._id), { addresses: addrs });
    setCurrentClient(prev => ({ ...prev, addresses: addrs }));
  }

  return (
    <View style={s.bg}>
      <View style={s.header}>
        <View style={s.avatar}><Text style={s.avatarTxt}>{initials(currentClient.name)}</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={s.name}>{currentClient.name}</Text>
          <Text style={s.phone}>{currentClient.phone}</Text>
        </View>
        <TouchableOpacity style={s.logoutBtn} onPress={() => { setCurrentClient(null); navigation.navigate('Login'); }}>
          <Text style={s.logoutTxt}>Sair</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }}>
        <View style={s.secRow}>
          <Text style={s.secTitle}>📍 Meus endereços</Text>
          <TouchableOpacity style={s.addBtn} onPress={() => setAddrModal(true)}>
            <Text style={s.addBtnTxt}>+ Adicionar</Text>
          </TouchableOpacity>
        </View>

        {(currentClient.addresses || []).length === 0 && (
          <Text style={s.noAddr}>Nenhum endereço cadastrado ainda.</Text>
        )}

        {(currentClient.addresses || []).map((a, i) => (
          <View key={i} style={[s.addrCard, a.default && s.addrDefault]}>
            <Text style={s.addrType}>
              {a.type === 'Casa' ? '🏠' : a.type === 'Trabalho' ? '🏢' : '📍'} {a.type}
              {a.default ? '  ⭐ Principal' : ''}
            </Text>
            <Text style={s.addrTxt}>{a.rua}, {a.num}{a.comp ? ` — ${a.comp}` : ''}{a.bairro ? `, ${a.bairro}` : ''} — {a.cidade}{a.cep ? ` (CEP ${a.cep})` : ''}</Text>
            <View style={s.addrActions}>
              {!a.default && (
                <TouchableOpacity onPress={() => setDefault(i)} style={s.actionBtn}>
                  <Text style={s.actionTxt}>Definir principal</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity onPress={() => removeAddr(i)} style={[s.actionBtn, s.actionDel]}>
                <Text style={[s.actionTxt, { color: C.red }]}>Remover</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>

      {/* Modal adicionar endereço */}
      <Modal visible={addrModal} animationType="slide" presentationStyle="pageSheet">
        <View style={s.modal}>
          <View style={s.modalHead}>
            <Text style={s.modalTitle}>📍 Novo endereço</Text>
            <TouchableOpacity style={s.modalX} onPress={() => setAddrModal(false)}>
              <Text style={s.modalXTxt}>✕</Text>
            </TouchableOpacity>
          </View>
          <ScrollView contentContainerStyle={{ padding: 18, gap: 10 }}>
            <View style={s.typeRow}>
              {['Casa', 'Trabalho', 'Outro'].map(t => (
                <TouchableOpacity key={t} style={[s.typeBtn, addrType === t && s.typeOn]} onPress={() => setAddrType(t)}>
                  <Text style={[s.typeTxt, addrType === t && s.typeTxtOn]}>
                    {t === 'Casa' ? '🏠 ' : t === 'Trabalho' ? '🏢 ' : '📍 '}{t}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            {[['Rua *', rua, setRua], ['Número *', num, setNum], ['Bairro', bairro, setBairro], ['Complemento', comp, setComp], ['Cidade *', cidade, setCidade], ['CEP', cep, setCep]].map(([lbl, val, setter]) => (
              <View key={lbl}>
                <Text style={s.lbl}>{lbl}</Text>
                <TextInput style={s.inp} value={val} onChangeText={setter} placeholder={lbl.replace(' *', '')} placeholderTextColor={C.grayL} />
              </View>
            ))}
            <TouchableOpacity style={[s.btn, saving && { opacity: 0.6 }]} onPress={saveAddr} disabled={saving}>
              <Text style={s.btnTxt}>{saving ? 'Salvando...' : '💾 Salvar endereço'}</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  bg:          { flex: 1, backgroundColor: C.dark },
  header:      { flexDirection: 'row', alignItems: 'center', gap: 14, paddingTop: 54, paddingHorizontal: 18, paddingBottom: 14, backgroundColor: C.dark2, borderBottomWidth: 1, borderBottomColor: C.gold + '33' },
  avatar:      { width: 48, height: 48, borderRadius: 24, backgroundColor: C.gold, justifyContent: 'center', alignItems: 'center' },
  avatarTxt:   { color: C.dark, fontWeight: '900', fontSize: 18 },
  name:        { color: C.white, fontWeight: '700', fontSize: 16 },
  phone:       { color: C.grayL, fontSize: 13 },
  logoutBtn:   { borderWidth: 1, borderColor: C.red + '66', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  logoutTxt:   { color: C.red, fontWeight: '700', fontSize: 13 },
  noLoginTxt:  { color: C.grayL, fontSize: 16 },
  btn:         { backgroundColor: C.gold, borderRadius: 13, padding: 14, alignItems: 'center' },
  btnTxt:      { color: C.dark, fontWeight: '700', fontSize: 15 },
  secRow:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  secTitle:    { color: C.silverL, fontWeight: '700', fontSize: 15 },
  addBtn:      { borderWidth: 2, borderColor: C.gold + '55', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 6 },
  addBtnTxt:   { color: C.gold, fontWeight: '700', fontSize: 13 },
  noAddr:      { color: C.grayL, fontSize: 13, textAlign: 'center', paddingVertical: 20 },
  addrCard:    { backgroundColor: C.dark2, borderWidth: 2, borderColor: '#333', borderRadius: 14, padding: 14, gap: 6 },
  addrDefault: { borderColor: C.gold + '66' },
  addrType:    { color: C.white, fontWeight: '700', fontSize: 14 },
  addrTxt:     { color: C.grayL, fontSize: 13, lineHeight: 18 },
  addrActions: { flexDirection: 'row', gap: 8, marginTop: 4 },
  actionBtn:   { borderWidth: 1, borderColor: '#444', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5 },
  actionDel:   { borderColor: C.red + '55' },
  actionTxt:   { color: C.grayL, fontSize: 12, fontWeight: '600' },
  modal:       { flex: 1, backgroundColor: C.dark },
  modalHead:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 54, paddingHorizontal: 18, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: C.gold + '33' },
  modalTitle:  { color: C.gold, fontSize: 18, fontWeight: '900' },
  modalX:      { backgroundColor: C.red, width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  modalXTxt:   { color: '#fff', fontWeight: '700' },
  typeRow:     { flexDirection: 'row', gap: 8 },
  typeBtn:     { flex: 1, borderWidth: 2, borderColor: '#333', borderRadius: 10, padding: 10, alignItems: 'center' },
  typeOn:      { borderColor: C.gold, backgroundColor: C.gold + '11' },
  typeTxt:     { color: C.grayL, fontWeight: '700', fontSize: 13 },
  typeTxtOn:   { color: C.gold },
  lbl:         { color: C.grayL, fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 5, marginTop: 4 },
  inp:         { backgroundColor: C.dark, borderWidth: 2, borderColor: '#2a2a2a', borderRadius: 11, padding: 12, color: C.white, fontSize: 14 },
});
